   caracter = getchar();
    caracter = getc(stdin);

       printf("Character entered: ");
       putchar(caracter);