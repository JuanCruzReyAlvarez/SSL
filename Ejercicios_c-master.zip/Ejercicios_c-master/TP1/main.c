#include "scanner.h"

int main(){    
    get_token();
    
    return 0;
}
